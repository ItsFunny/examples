#!/bin/bash


#docker exec cli bash -c "echo \$CORE_PEER_LOCALMSPID > ./msp.txt"
#msp=$(cat ./workspace/msp.txt)
#echo "msp": $msp

#configFile="$GOPATH/src/bidchain/chaincode/fabric_info_online.json"

# 配置文件路径
configFile="$GOPATH/src/bidchain/chaincode/fabric_info_local.json"
# Org列表
mspList="BidsunMSP GuangzhouMSP"

for msp in $mspList; do

    # 当前组织Channel列表
    channelList=$(jq -r '.MSP | .["'$msp'"] | .channels[] ' $configFile)
    #channelList=ebidsun-performance

    # 当前组织Peer 列表
    peerList=$(jq -r '.MSP | .["'$msp'"] | .peers[]' $configFile)
    EBIDSUN_ALPHA="ebidsun-alpha"
    echo "=====channelList:" $channelList "====="
    echo "=====peerList:" $peerList "====="

    # 遍历Channel列表
    for channelName in $channelList; do
        #if [[ $channelName != "ebidsun-alpha" ]]; then
        #    continue
        #fi
        if [[ $msp = "BidsunMSP" ]]; then
            echo "=====generating channel[$channelName] config file====="
            if [[ $channelName = $EBIDSUN_ALPHA ]]; then
                configtxgen -profile TwoOrgsChannel  -outputCreateChannelTx ./channel-artifacts/channel.tx -channelID $EBIDSUN_ALPHA 
            else
                profile=`echo $channelName | sed 's/^\w\|\s\w/\U&/g'`Channel
                set -x 
                configtxgen -profile $profile -outputCreateChannelTx ./channel-artifacts/$channelName.tx -channelID $channelName
                set +x
            fi
        fi

#  echo "=====updating anchor peers====="
#  if [[ $channelName = $EBIDSUN_ALPHA ]]; then
#    #configtxgen -profile BidchainChannel -outputAnchorPeersUpdate ./channel-artifacts/$msp"anchors.tx" -channelID $EBIDSUN_ALPHA -asOrg $msp
#    configtxgen -profile TwoOrgsChannel -outputAnchorPeersUpdate ./channel-artifacts/${msp}anchors.tx -channelID $EBIDSUN_ALPHA -asOrg $msp
#  else
#   profile=`echo $channelName | sed 's/^\w\|\s\w/\U&/g'`Channel
#   configtxgen -profile $profile -outputAnchorPeersUpdate ./channel-artifacts/${msp}_${profile}_Anchors.tx -channelID $channelName -asOrg $msp
#  fi
    done
done

docker exec cli scripts/create_channel_step.sh
