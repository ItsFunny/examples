#!/bin/bash

for((i=0;i<5;i++)) {
  echo "=============peer$i.bidsun.com====================="
  sudo nsenter -t $(docker inspect -f '{{.State.Pid}}' peer$i.bidsun.com) -n netstat -ant | sed 's/192.168.176.106/peer4.guangzhou.com/g' |sed 's/192.168.176.105/peer3.guangzhou.com/g' |sed 's/192.168.176.104/peer2.guangzhou.com/g' |sed 's/192.168.176.103/peer1.guangzhou.com/g' |sed 's/192.168.176.102/peer0.guangzhou.com/g' | sed 's/192.168.176.99/peer4.bidsun.com/g' |sed 's/192.168.176.98/peer3.bidsun.com/g' |sed 's/192.168.176.97/peer2.bidsun.com/g' |sed 's/192.168.176.101/peer1.bidsun.com/g' |sed 's/192.168.176.100/peer0.bidsun.com/g' 
  echo "======================================="
}

for((i=0;i<5;i++)) {
  echo "=============peer$i.guangzhou.com====================="
  sudo nsenter -t $(docker inspect -f '{{.State.Pid}}' peer$i.guangzhou.com) -n netstat -ant | sed 's/192.168.176.106/peer4.guangzhou.com/g' |sed 's/192.168.176.105/peer3.guangzhou.com/g' |sed 's/192.168.176.104/peer2.guangzhou.com/g' |sed 's/192.168.176.103/peer1.guangzhou.com/g' |sed 's/192.168.176.102/peer0.guangzhou.com/g' | sed 's/192.168.176.99/peer4.bidsun.com/g' |sed 's/192.168.176.98/peer3.bidsun.com/g' |sed 's/192.168.176.97/peer2.bidsun.com/g' |sed 's/192.168.176.101/peer1.bidsun.com/g' |sed 's/192.168.176.100/peer0.bidsun.com/g' 
  echo "======================================="
}
