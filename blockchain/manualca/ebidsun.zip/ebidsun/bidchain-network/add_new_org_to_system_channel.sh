#
# Use the CLI container to create the configuration transaction needed to add
# to the network
function createConfigTx () {
  docker exec cli scripts/add_new_org_step1_to_system_channel.sh $CHANNEL_NAME  $ORDERER_ADDRESS $ORDERER_CA $NEW_ORG_NAME $NEW_ORG_MSPID
  if [ $? -ne 0 ]; then
    echo "ERROR !!!! Unable to create config tx"
    exit 1
  fi
}


export CHANNEL_NAME=bidchain-sys-channel
export ORDERER_ADDRESS=orderer.bidsun.com:7050
export ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem
NEW_ORG_NAME=$1
NEW_ORG_MSPID=`echo $NEW_ORG_NAME|sed 's/^\w\|\s\w/\U&/g'`MSP

createConfigTx
