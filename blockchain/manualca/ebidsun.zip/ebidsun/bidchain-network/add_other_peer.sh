#!/bin/bash

docker exec cli scripts/add_other_peers.sh 
