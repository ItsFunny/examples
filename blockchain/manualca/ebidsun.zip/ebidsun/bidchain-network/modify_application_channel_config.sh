
# Use the CLI container to create the configuration transaction needed to add
# to the network
function createConfigTx () {
  docker exec cli scripts/modify_application_channel_step.sh $CHANNEL_NAME  $ORDERER_ADDRESS $ORDERER_CA $max_message_count $batch_timeout $absolute_max_bytes $preferred_max_bytes
  if [ $? -ne 0 ]; then
    echo "ERROR !!!! Unable to create config tx"
    exit 1
  fi
}

if [[ $1 == "" ]]; then
 echo "Usage: ./modify_application_channel_config.sh <channelName> <max_message_count> <batch_timeout> <absolute_max_bytes> <preferred_max_bytes>"
 exit 0
fi
export CHANNEL_NAME=$1
export ORDERER_ADDRESS=orderer.bidsun.com:7050
export ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem
max_message_count=${2:-1000}
# 时间要带单位
batch_timeout=${3:-2s}
absolute_max_bytes=${4:-103809024}
preferred_max_bytes=${5:-524288}

createConfigTx
