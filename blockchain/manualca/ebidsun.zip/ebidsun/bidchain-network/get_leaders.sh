#!/bin/bash

for((i=0;i<5;i++)) {
    echo "peer${i}.bidsun.com"
    docker logs peer${i}.bidsun.com 2>&1 | grep "leaderElection"
}

for((i=0;i<5;i++)) {
    echo "peer${i}.guangzhou.com"
    docker logs peer${i}.guangzhou.com 2>&1 | grep "leaderElection"
}
