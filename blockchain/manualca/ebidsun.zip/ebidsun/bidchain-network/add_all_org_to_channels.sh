#!/bin/bash

configFile=$GOPATH/src/bidchain/chaincode/fabric_config_online.json
mspList=$(jq -r '.MSP | keys[]' $configFile)

for msp in $mspList; do
   #if [[ $msp = "BidsunMSP" ]];then
   if [[ $msp = "BidsunMSP" ||  $msp = "GuangzhouMSP" || $msp = "BeijingMSP" ]];then
     continue
   fi
   channelList=$(jq -r '.MSP | .["'$msp'"] | .channels[]' $configFile)
   for channelName in $channelList; do
     orgName=$(echo $msp | tr -d "MSP" | sed 's/^\w\|\s\w/\L&/g')
     ./add_new_org.sh $channelName $orgName
   done
done
