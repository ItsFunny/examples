#!/bin/bash
set -e

. scripts/utils.sh 2>/dev/null|| . utils.sh


version_gt() {
    test "$(echo "$@" | tr " " "\n" | sort | head -n 1)" != "$1";
}

useWantedChaincodes=false
declare -A chaincodeMap
for cp in `cat scripts/wantedChaincodes.txt | grep -v ^#`; do
  cc=$(basename $cp) 
  chaincodeMap[$cc]=$cc
done
echo "chaincodeMap:" ${chaincodeMap[@]}


setEnv() {
    PEER0_ORG1_CA=/opt/workspace/crypto/peerOrganizations/bidsun.com/peers/peer0.bidsun.com/tls/ca.crt
    PEER0_ORG2_CA=/opt/workspace/crypto/peerOrganizations/guangzhou.com/peers/peer0.guangzhou.com/tls/ca.crt
    PEER0_ORG3_CA=/opt/workspace/crypto/peerOrganizations/zhuhai.com/peers/peer0.zhuhai.com/tls/ca.crt
      if [[ $msp = "BidsunMSP" ]]; then
        CORE_PEER_ADDRESS="peer0.bidsun.com:7051"
        CORE_PEER_LOCALMSPID="BidsunMSP"
        CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
        CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/peerOrganizations/bidsun.com/users/Admin@bidsun.com/msp

      elif [[ $msp = "GuangzhouMSP" ]]; then
        CORE_PEER_ADDRESS="peer0.guangzhou.com:9051"
        CORE_PEER_LOCALMSPID="GuangzhouMSP"
        CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
        CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/peerOrganizations/guangzhou.com/users/Admin@guangzhou.com/msp
      fi  
}

# 初始化链码
instantiateOrUpgradeChaincode() {
    # 链码路径
    PREFIX=$GOPATH/src/bidchain/chaincode
    CHAINCODE_PREFIX=bidchain/chaincode
    cd $PREFIX

    local index=0
    # 遍历所有链码
for chaincodePath in $chaincodePaths; do
            # 链码名称
            local file=$(basename $chaincodePath)
            CHANNEL_NAME=$(jq -r '.MSP | .["'$msp'"] | .chaincodes['$index'].channelName' $configPath)
            index=$((index+1))
            
            CHAINCODE_PATH=$chaincodePath
            CHAINCODE_NAME=$file

            
            if [[ $useWantedChaincodes = true ]]; then
                if ! [[ ${chaincodeMap[$file]} ]];then 
                   continue
                fi
            fi  
            echo "CHANNEL_NAME:" $CHANNEL_NAME
            echo "CHAINCODE_NAME: " $CHAINCODE_NAME
            
            # 从配置文件获取当前链码版本号
            version=$(cat version_local.json | jq .$file.version)
            #version=$(cat version.json | jq .$file.version)

            echo "chaincode path"  $CHAINCODE_PATH
            #echo "chaincode name"  $CHAINCODE_NAME
            version=${version:1:-1}
    
            if [ $version == "null" ] || [ $version == "" ]; then
                echo "invalid version $version for chaincode $CHAINCODE_NAME"
                exit 0
            fi  

            # 低版本不更新
            #set -x
            # 获取已经实例化链码版本
            INSTANTIATED_VERSION=$(peer chaincode list --instantiated -C $CHANNEL_NAME | grep "Name: $CHAINCODE_NAME," | awk -F, '{print $2}' | cut -d: -f2 | tr -d " ")
            instantiatedChaincodeVersion=$INSTANTIATED_VERSION
            #set +x
            echo "instantied version:" $INSTANTIATED_VERSION
             # 低版本跳过
            if [[ "$INSTANTIATED_VERSION" != "" ]]; then
                if  ! version_gt $version  $INSTANTIATED_VERSION ; then 
                        echo "skip instantitate or uprade chaincode $CHAINCODE_NAME, latest instantiated version: $INSTANTIATED_VERSION, wanted to instantiate or upgrade version: $version"
                        echo "=================================================================================================================================="
                        continue
                fi  
            fi  

             
            echo "chaincode version is" $version
            policy=$(cat version_local.json | jq '.'$CHAINCODE_NAME'.policy')
            policy=${policy:1:-1}


            #if [[ $policy == "null" ]] || [[ $policy == "" ]]; then 
                #policy=$(cat version.json | jq .default.policy)
            #    policy=$(cat version_local.json | jq .default.policy)
            #fi 
            #policy=${policy:1:-1}
            echo "policy is:" $policy
            #policy="AND('BidsunMSP.peer', 'GuangzhouMSP.peer')"
            #policy="AND('BidsunMSP.peer')"
            #policy="AND('GuangzhouMSP.peer')"
            #echo "change endorsement policy to: $policy"
            # 之前没有实例化
            if [[ $instantiatedChaincodeVersion == "" ]]; then
               #实力化(初始化)操作
               echo "instantiated chaincode:" $file "version:" $version  
               
               setGlobals 0 1
               #set -x
               startTime=$(date +%s)
               set -x
               peer chaincode instantiate -o orderer.bidsun.com:7050 --tls --cafile $ORDERER_CA -C $CHANNEL_NAME -n $CHAINCODE_NAME -v $version -c '{"Args":[""]}' -P "$policy" 2> chaincode_instantiate.log
               ret=$?
               set +x
               deltaTime=$(($(date +%s) - startTime))
               if [[ $ret -ne 0 ]]; then
                 cat chaincode_instantiate.log
                 exit 0
               fi

               #set +x
               ret=$?
               verifyResult $ret
           
              #( sleep 10 && msp="GuangzhouMSP" && setEnv && set +e && peer chaincode query -C $CHANNEL_NAME -n $CHAINCODE_NAME -c '{"Args":["GetUnknownXXX"]}' &> /dev/null ) &
              #sleep 2
              #echo "start chaincode:$CHAINCODENAME  channel:$CHANNEL_NAME on peer0.guangzhou.com"
              #msp="GuangzhouMSP"
              #setEnv 
              #set +e
              #peer chaincode query -C $CHANNEL_NAME -n $CHAINCODE_NAME -c '{"Args":["GetUnknownXXX"]}' &> /dev/null
              set -e
              msp="GuangzhouMSP"
              setEnv


               echo "succesfully instantiate chaincode" $CHAINCODE_NAME
               echo "instantiate chaincode time usage:" $deltaTime
            elif  version_gt $version $instantiatedChaincodeVersion ; then
               setGlobals 0 1
               #set -x
               startTime=$(date +%s)
               set -x
               peer chaincode upgrade -o orderer.bidsun.com:7050 --tls --cafile $ORDERER_CA -C $CHANNEL_NAME -n $CHAINCODE_NAME -v $version -c '{"Args":[""]}' -P "$policy" 2> chaincode_instantiate.log
               set +x
               ret=$?
               endTime=$(date +%s)
               deltaTime=$(($endTime - startTime))
               if [[ $ret -ne 0 ]]; then
                 cat chaincode_instantiate.log
                 exit 0
               fi
               #set +x
               ret=$?
               verifyResult $ret

              #echo "uprade success" $(date)
              #echo "start chaincode:$CHAINCODE_NAME  channel:$CHANNEL_NAME on peer0.guangzhou.com"
              #sleep 10
              #msp="GuangzhouMSP"
              #setEnv 
              #set +e
              #peer chaincode query -C $CHANNEL_NAME -n $CHAINCODE_NAME -c '{"Args":["GetUnknownXXX"]}' &> /dev/null
              ( sleep 10 && msp="GuangzhouMSP" && setEnv && set +e && peer chaincode query -C $CHANNEL_NAME -n $CHAINCODE_NAME -c '{"Args":["GetUnknownXXX"]}' &> /dev/null ) &
              #peer chaincode query -C $CHANNEL_NAME -n $CHAINCODE_NAME -c '{"Args":["GetUnknownXXX"]}' 
              #set -e
              #msp="BidsunMSP"
              #setEnv
               echo "succesfully upgrade chaincode" $CHAINCODE_NAME
               echo "upgrade chaincode time usage:" $deltaTime
               echo "endTime: " $endTime
            fi 
            echo "=================================================================================================================================="
     done
}



echo "=====================================================instantiate chaincode========================================================"

#msp=$CORE_PEER_LOCALMSPID
msp="GuangzhouMSP"
echo "msp": $msp

configPath="$GOPATH/src/bidchain/chaincode/fabric_info_local.json"
chaincodePaths=$(jq -r '.MSP | .["'$msp'"] | .chaincodes[] | .chaincodePath' $configPath)
echo "chaincodes:" $chaincodePaths

#peerList=$(jq -r '.MSP | .["'$msp'"] | .peers[]' $configPath)
#echo "peers:" $peerList

chaincodeNum=$(echo $chaincodePaths | tr " " "\n" | wc -l)
echo "chaincodeNums: " $chaincodeNum

peerAddress="peer0.guangzhou.com"
instantiateOrUpgradeChaincode $peerAddress

wait
echo "end"
