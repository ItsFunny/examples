#!/bin/bash

. cleanChaincodeContainers.sh
. cleanChaincodeImages.sh
. cleanAllPeerChaincodes.sh
