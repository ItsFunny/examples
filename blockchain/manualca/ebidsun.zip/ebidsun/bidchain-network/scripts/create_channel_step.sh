#!/bin/bash

. scripts/utils.sh

setEnv() {
	PEER0_ORG1_CA=/opt/workspace/crypto/peerOrganizations/bidsun.com/peers/peer0.bidsun.com/tls/ca.crt
	PEER0_ORG2_CA=/opt/workspace/crypto/peerOrganizations/guangzhou.com/peers/peer0.guangzhou.com/tls/ca.crt
	PEER0_ORG3_CA=/opt/workspace/crypto/peerOrganizations/zhuhai.com/peers/peer0.zhuhai.com/tls/ca.crt

	if [[ $msp == "BidsunMSP" ]]; then

		CORE_PEER_LOCALMSPID="BidsunMSP"
		CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
		CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/peerOrganizations/bidsun.com/users/Admin@bidsun.com/msp

	elif [[ $msp == "GuangzhouMSP" ]]; then
		CORE_PEER_LOCALMSPID="GuangzhouMSP"
		CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
		CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/peerOrganizations/guangzhou.com/users/Admin@guangzhou.com/msp

	else

		echo "msp[$msp] does not configure env"
		exit 0
	fi
}

configFile=$GOPATH/src/bidchain/chaincode/fabric_info_local.json
#configFile=$GOPATH/src/bidchain/chaincode/fabric_info_online.json
#msp=$CORE_PEER_LOCALMSPID
mspList="BidsunMSP GuangzhouMSP"
for msp in $mspList; do
	echo "msp:" $msp
	setEnv
	channelList=$(jq -r '.MSP | .["'$msp'"] | .channels[] ' $configFile)
	#channelList=ebidsun-performance
	logFile=channel.log
	peerList=$(jq -r '.MSP | .["'$msp'"] | .peers[]' $configFile)
	EBIDSUN_ALPHA="ebidsun-alpha"

	for channelName in $channelList; do

		#if [[ $channelName != "ebidsun-alpha" ]]; then
		#    continue
		#fi

		if [[ $msp == "BidsunMSP" ]]; then
			echo "======creating channel:" $channelName "======"
			if [[ $channelName == "ebidsun-alpha" ]]; then
				set -x
				peer channel create -o orderer.bidsun.com:7050 -c $channelName -f ./channel-artifacts/ebidsun-wim-test.tx --tls true --cafile $ORDERER_CA &>$logFile
				ret=$?
				set +x
			else
				set -x
				peer channel create -o orderer.bidsun.com:7050 -c $channelName -f ./channel-artifacts/$channelName.tx --tls true --cafile $ORDERER_CA &>$logFile
				ret=$?
				set +x
			fi
			#echo "ret:" $ret
			if [[ $ret -ne 0 ]]; then
				grep -q "existing channel" $logFile
				if [[ $? -eq 0 ]]; then
					echo "channel $channelName already exists"
					#continue
				else
					cat $logFile
					echo "程序异常终止!!!!"
					exit 0
				fi
			fi

		fi
        
        sleep 2

		#echo "peerList" $peerList
		for peerAddress in $peerList; do
			echo "===== $peerAddress Join channel[$channelName]====="
			CORE_PEER_ADDRESS=$peerAddress
			peer channel list 2>&1  |  grep -q $channelName
			#peer channel list &> $logFile | grep -q $channelName
			#peer channel list 2>&1  | grep -q $channelName
			#peer channel list 2>&1 > /dev/null  | grep -q $channelName
			if [[ $? -eq 1 ]]; then
				peer channel join -b $channelName".block" &>$logFile

				ret=$?
				if [[ $ret -ne 0 ]]; then
					grep -q "LedgerID already exists" $logFile
					if [[ $? -eq 0 ]]; then
						echo "channel $channelName already exists"
						continue
					else
						cat $logFile
						echo "程序异常终止!!!!"
						exit 0
					fi
				fi
			else
				echo ""
			fi

		done

		#  echo "=====updating anchor peers in channel[$channelName]====="
		#  if [[ $channelName == "ebidsun-alpha" ]]; then
		#  set -x
		#  peer channel update -o orderer.bidsun.com:7050 -c $channelName -f ./channel-artifacts/${msp}anchors.tx --tls --cafile $ORDERER_CA
		#  ret=$?
		#  set +x
		#  else
		#  set -x
		#
		#  profile=`echo $channelName | sed 's/^\w\|\s\w/\U&/g'`Channel
		#  peer channel update -o orderer.bidsun.com:7050 -c $channelName -f ./channel-artifacts/${msp}_${profile}_Anchors.tx --tls --cafile $ORDERER_CA
		#  ret=$?
		#  set +x
		#  fi
		#  #echo "ret:" $ret
		#  if [[ $ret -eq 0 ]]; then
		#    continue
		#  else
		#     exit 0
		#  fi
	done
done
