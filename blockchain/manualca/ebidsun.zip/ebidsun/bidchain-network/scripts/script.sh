#!/bin/bash

echo -e "Build your first network (BYFN) end-to-end test\n"

CHANNEL_NAME="$1"
DELAY="$2"
LANGUAGE="$3"
TIMEOUT="$4"
VERBOSE="$5"
NO_CHAINCODE="$6"
: ${CHANNEL_NAME:="ebidsun-alpha"}
: ${DELAY:="1"}
: ${LANGUAGE:="golang"}
: ${TIMEOUT:="10"}
: ${VERBOSE:="false"}
: ${NO_CHAINCODE:="false"}
LANGUAGE=`echo "$LANGUAGE" | tr [:upper:] [:lower:]`
COUNTER=1
MAX_RETRY=10

ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem

echo "Channel name : "$CHANNEL_NAME

# import utils
 . scripts/utils.sh 2>/dev/null|| . utils.sh

createChannel() {
  setGlobals 0 1
  if [ -z "$CORE_PEER_TLS_ENABLED" -o "$CORE_PEER_TLS_ENABLED" = "false" ]; then
        set -x
	peer channel create -o orderer.bidsun.com:7050 -c $CHANNEL_NAME -f ./channel-artifacts/channel.tx >&log.txt
	res=$?
        set +x
  else
	set -x
	peer channel create -o orderer.bidsun.com:7050 -c $CHANNEL_NAME -f ./channel-artifacts/channel.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA >&log.txt
	res=$?
	set +x
  fi
  cat log.txt
  verifyResult $res "Channel creation failed"
  echo -e  "===================== Channel '$CHANNEL_NAME' created =====================\n"
}

joinChannel () {
  for org in 1 2; do
    for peer in 0 1; do
#    for peer in 0 ; do
	joinChannelWithRetry $peer $org
	echo "===================== peer${peer}.org${org} joined channel '$CHANNEL_NAME' ===================== "
	sleep $DELAY
	echo
    done
  done
}

## Create channel
echo "Creating channel..."
createChannel

## Join all the peers to the channel
echo "Having all peers join the channel..."
joinChannel

## Set the anchor peers for each org in the channel
echo "Updating anchor peers for org1..."
updateAnchorPeers 0 1
echo "Updating anchor peers for org2..."
updateAnchorPeers 0 2

install_instantiateChaincode() {
    PREFIX=$GOPATH/src/bidchain/chaincode
    CHAINCODE_PREFIX=bidchain/chaincode
    CHANNEL_NAME=ebidsun-alpha
    cd $PREFIX
    for file in `ls -d */|sed 's/\///g'`;do
            CHAINCODE_PATH=$CHAINCODE_PREFIX/$file
            CHAINCODE_NAME=$file
            #version=$(cat version.json | jq .$file)
    
            version="1.0.0"
            echo "chaincode path"  $CHAINCODE_PATH
            echo "chaincode name"  $CHAINCODE_NAME
            #version=${version:1:-1}
       
            #if [[ $version == "null" ]] || [[ $version == "" ]]; then
                #echo "invalid version $version for chaincode $CHAINCODE_NAME"
                #continue
            #fi  
            #echo "chaincode version is" $version


	    ##install peer0.org1
            echo "Installing chaincode" $CHAINCODE_NAME "on peer0.org1..."
            setGlobals 0 1
            set -x
            peer chaincode install -n $CHAINCODE_NAME -v $version -p $CHAINCODE_PATH
            set +x
            ret=$?
            verifyResult $ret
            echo "succesfully install chaincode" $CHAINCODE_NAME "on peer0.org1..."

	    ##install peer0.org2
            echo "Installing chaincode" $CHAINCODE_NAME "on peer0.org2..."
            setGlobals 0 2
            set -x
            peer chaincode install -n $CHAINCODE_NAME -v $version -p $CHAINCODE_PATH
            set +x
            ret=$?
            verifyResult $ret
            echo "succesfully install chaincode" $CHAINCODE_NAME "on peer0.org2..."

            # Instantiate chaincode on peer0.org1
            echo "Instantiating chaincode" $CHAINCODE_NAME "on peer0.org1..."
            setGlobals 0 1
            set -x
            peer chaincode instantiate -o orderer.bidsun.com:7050 --tls --cafile $ORDERER_CA -C $CHANNEL_NAME -n $CHAINCODE_NAME -v $version -c '{"Args":[""]}' -P 'AND("BidsunMSP.peer", "GuangzhouMSP.peer")'
            set +x
            ret=$?
            verifyResult $ret
            echo "succesfully instantiate chaincode" $CHAINCODE_NAME "on peer0.org1..."
    done
}
#install_instantiateChaincode

echo -e "\n========= All GOOD, BYFN execution completed =========== "
exit 0
