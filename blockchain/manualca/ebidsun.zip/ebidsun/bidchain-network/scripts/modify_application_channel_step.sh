#!/bin/bash
set -x

export CHANNEL_NAME=$1
export ORDERER_ADDRESS=$2
export ORDERER_CA=$3
max_message_count=$4
batch_timeout=$5
absolute_max_bytes=$6
preferred_max_bytes=$7

. scripts/utils.sh.org3

setOrdererGlobals() {
   CORE_PEER_ADDRESS=orderer.bidsun.com:7050
   CORE_PEER_LOCALMSPID=OrdererMSP
   CORE_PEER_TLS_ENABLED=true
   CORE_PEER_TLS_CERT_FILE=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/tls/server.crt
   CORE_PEER_TLS_KEY_FILE=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/tls/server.crt 
   CORE_PEER_TLS_ROOTCERT_FILE=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/tls/ca.crt
   CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/ordererOrganizations/bidsun.com/users/Admin@bidsun.com/msp/
   ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem
}


#setOrdererGlobals

#echo "========= Creating config transaction to add $NEW_ORG_NAME to network =========== "
# Fetch the config for the channel, writing it to config.json
fetchChannelConfig $ORDERER_ADDRESS $ORDERER_CA ${CHANNEL_NAME} config.json

jq --arg v1 $max_message_count --arg v2  $batch_timeout --arg v3 $absolute_max_bytes --arg v4 $preferred_max_bytes '.channel_group.groups.Orderer.values.BatchSize.value.max_message_count = ($v1 | tonumber) | .channel_group.groups.Orderer.values.BatchTimeout.value.timeout = $v2 | .channel_group.groups.Orderer.values.BatchSize.value.absolute_max_bytes = ($v3 | tonumber) | .channel_group.groups.Orderer.values.BatchSize.value.preferred_max_bytes = ($v4 | tonumber)' config.json >  modified_config.json



createConfigUpdate ${CHANNEL_NAME} config.json modified_config.json $NEW_ORG_NAME"_update_in_envelope.pb" $NEW_ORG_MSPID

peer channel update -f $NEW_ORG_NAME"_update_in_envelope.pb" -c ${CHANNEL_NAME} -o $ORDERER_ADDRESS --tls --cafile ${ORDERER_CA} 2> error.log || (cat error.log; exit 1)

echo "successfully channel $CHANNEL_NAME configuration"

