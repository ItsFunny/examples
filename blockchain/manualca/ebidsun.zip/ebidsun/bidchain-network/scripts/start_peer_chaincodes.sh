#!/bin/bash


. scripts/utils.sh 2>/dev/null|| . utils.sh

version_gt() {
    test "$(echo "$@" | tr " " "\n" | sort | head -n 1)" != "$1";
}

useWantedChaincodes=false
declare -A chaincodeMap
for cp in `cat scripts/wantedChaincodes.txt | grep -v ^#`; do
  cc=$(basename $cp) 
  chaincodeMap[$cc]=$cc
done
echo "chaincodeMap:" ${chaincodeMap[@]}

msp="GuangzhouMSP"
CORE_PEER_LOCALMSPID="GuangzhouMSP"
CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/peerOrganizations/guangzhou.com/users/Admin@guangzhou.com/msp
configPath="$GOPATH/src/bidchain/chaincode/fabric_info_local.json"
#chaincodePaths=$(jq -r '.MSP | .["'$msp'"] | .chaincodes[] | .chaincodePath' $configPath)
#echo "chaincodes:" $chaincodePaths
#chaincodeNum=$(echo $chaincodePaths | tr " " "\n" | wc -l)
#echo "chaincodeNums: " $chaincodeNum
#peerAddress="peer0.guangzhou.com"


chaincodeInfos=$(jq -r '.MSP | .["'$msp'"].chaincodes[] | [.channelName, .chaincodePath]| @tsv' $configPath)




