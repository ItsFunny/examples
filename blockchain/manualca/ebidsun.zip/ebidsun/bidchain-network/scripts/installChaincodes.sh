#!/bin/bash
set -e

# 加载脚本 引入scripts/utils.sh 失败 丢弃错误 并 尝试引入 utils.sh
# import utils
. scripts/utils.sh 2>/dev/null|| . utils.sh



# 比较Chaincode 版本是否满足 a > b
version_gt() {
    test "$(echo "$@" | tr " " "\n" | sort | head -n 1)" != "$1";
}

# 验证版本号是否有效
validateVersion() {
  local version=$1
  grep -Pq '^\d{1,3}(\.\d){1,2}$' <<<$version
  if [[ $? -ne 0 ]]; then
    echo "invalid version:" $version
    exit 0
  fi
}


useWantedChaincodes=false
declare -A chaincodeMap
# 获取wantedChaincodes.txt 中 不是#开头的链码名称 并存储到Map中
for cp in `cat scripts/wantedChaincodes.txt | grep -v ^#`; do
   cc=$(basename $cp) 
   chaincodeMap[$cc]=$cc
done
echo "chaincodeMap:" ${chaincodeMap[@]}

# 配置Org环境变量
setEnv() {
    PEER0_ORG1_CA=/opt/workspace/crypto/peerOrganizations/bidsun.com/peers/peer0.bidsun.com/tls/ca.crt
    PEER0_ORG2_CA=/opt/workspace/crypto/peerOrganizations/guangzhou.com/peers/peer0.guangzhou.com/tls/ca.crt
    PEER0_ORG3_CA=/opt/workspace/crypto/peerOrganizations/zhuhai.com/peers/peer0.zhuhai.com/tls/ca.crt
      if [[ $msp = "BidsunMSP" ]]; then
        CORE_PEER_LOCALMSPID="BidsunMSP"
        CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
        CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/peerOrganizations/bidsun.com/users/Admin@bidsun.com/msp

      elif [[ $msp = "GuangzhouMSP" ]]; then
        CORE_PEER_LOCALMSPID="GuangzhouMSP"
        CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
        CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/peerOrganizations/guangzhou.com/users/Admin@guangzhou.com/msp
      fi  
}


# 安装链码
installChaincodes() {
    # 链码文件目录
    PREFIX=$GOPATH/src/bidchain/chaincode
    cd $PREFIX
    
    # 遍历排序好的链码路径
    for chaincodePath in $chaincodePaths; do
            # 拿到链码名
            local file=$(basename $chaincodePath)

            CHAINCODE_PATH=$chaincodePath
            CHAINCODE_NAME=$file

            if [[ $useWantedChaincodes = true ]]; then
               # 如果不是想要安装的，跳过
               if ! [[ ${chaincodeMap[$file]} ]]; then
                  continue
                fi
            fi
                  
            # 通过jq获取对应链码的Version 
            version=$(cat version_local.json | jq .$file.version)
            #version=$(cat version.json | jq .$file.version)
            echo "chaincode path"  $CHAINCODE_PATH
            echo "chaincode name"  $CHAINCODE_NAME
            version=${version:1:-1}

            # Version为空跳过当前链码安装 
            if [ $version = "null" ] || [ $version = "" ]; then
                echo "invalid version $version for chaincode $CHAINCODE_NAME"
                continue
            fi  

            # 验证版本号是否有效
            validateVersion $version
            echo "chaincode version is" $version
        
        # 遍历当前组织Peer列表
      for peerAddress in $peerList; do
            CORE_PEER_ADDRESS=$peerAddress

            # 验证是否已经安装
            LATEST_INSTALLED_VERSION=$(peer chaincode list --installed |  grep "Name: $CHAINCODE_NAME," | awk -F, '{print $2}' | awk -F: '{print $2}' | tr -d ' ' | tail -n 1)
            
            # 低版本跳过
            if [[ "$LATEST_INSTALLED_VERSION" != "" ]]; then
                if  ! version_gt $version  $LATEST_INSTALLED_VERSION ; then 
                        echo "skip install chaincode $CHAINCODE_NAME, latest installed version: $LATEST_INSTALLED_VERSION, wanted to install version: $version"
                        echo "========================================================================================"
                        continue
                fi
            fi

            # 安装链码
            echo "Installing chaincode" $CHAINCODE_NAME "on $CORE_PEER_ADDRESS..."
            peer chaincode install -n $CHAINCODE_NAME -v $version -p $CHAINCODE_PATH 2> chaincode_install.log
            ret=$?
            if [[ $ret -ne 0 ]]; then
                cat chaincode_install.log
                exit 0
            fi
            echo "succesfully install chaincode" $CHAINCODE_NAME "on $CORE_PEER_ADDRESS..."
            echo "========================================================================================"

    done
done
}

setEnv() {
PEER0_ORG1_CA=/opt/workspace/crypto/peerOrganizations/bidsun.com/peers/peer0.bidsun.com/tls/ca.crt
PEER0_ORG2_CA=/opt/workspace/crypto/peerOrganizations/guangzhou.com/peers/peer0.guangzhou.com/tls/ca.crt
PEER0_ORG3_CA=/opt/workspace/crypto/peerOrganizations/zhuhai.com/peers/peer0.zhuhai.com/tls/ca.crt
  if [[ $msp = "BidsunMSP" ]]; then
    CORE_PEER_LOCALMSPID="BidsunMSP"
    CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
    CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/peerOrganizations/bidsun.com/users/Admin@bidsun.com/msp

  elif [[ $msp = "GuangzhouMSP" ]]; then
    CORE_PEER_LOCALMSPID="GuangzhouMSP"
    CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
    CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/peerOrganizations/guangzhou.com/users/Admin@guangzhou.com/msp
  fi
}

# 链配置文件路径
configPath="$GOPATH/src/bidchain/chaincode/fabric_info_local.json"
#msp=$CORE_PEER_LOCALMSPID

# 组织列表
mspList="BidsunMSP GuangzhouMSP"

for msp in $mspList; do 
# 设置环境变量
    setEnv

    echo "========================================msp": $msp "======================================"
# 获取当前组织所有链码路径 并排序
    chaincodePaths=$(jq -r '.MSP | .["'$msp'"] | .chaincodes[] | .chaincodePath' $configPath | sort | uniq)
    echo "chaincodeList:" $chaincodePaths

# 获取当前组织所有Peer
    peerList=$(jq -r '.MSP | .["'$msp'"] | .peers[]' $configPath)
    echo "peerList:" $peerList

# 安装链码
    installChaincodes 
done
