#!/bin/bash
set -ev

. scripts/utils.sh  2>/dev/null

CHANNEL_NAME=ebidsun-alpha
DELAY=1
COUNTER=1
MAX_RETRY=10

joinChannel () {
  for org in 1; do
    for peer in 4; do
    joinChannelWithRetry $peer $org
    echo "===================== peer${peer}.org${org} joined channel '$CHANNEL_NAME' ===================== "
    sleep $DELAY
    echo
    done
  done
}


#Join other peers to the channel
echo "Having all peers join the channel..."
joinChannel




