#!/bin/bash
set -eu


# 删除peer节点安装的特定版本链码
removeSpecificPeerChaincodes() {
    # 获取所有的peer节点
    peerIds=$(docker ps | grep "hyperledger/fabric-peer" | awk '{print $1}')
    for peerId in $peerIds
    do  
       docker exec $peerId bash -c '
        echo "==================peer address: $CORE_PEER_ADDRESS ========================="
        cd /var/hyperledger/production/chaincodes/
        for ((i =1; i < $#; i+=2))
        do
            chaincodeName=${!i}
            index=$((i+1))
            version=${!index}
            fileName=$chaincodeName.$version
            rm -fv $fileName
        done
       ' xxx $*
    # xxx只是占位填充,没有任何意义
    done 
}

if [ $(($# % 2)) == 1 ]; then
    echo "输入参数个数必须为偶数,形如 key1 value1 key2 value2"
fi



removeSpecificPeerChaincodes $*
