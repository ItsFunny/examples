
# Use the CLI container to create the configuration transaction needed to add
# to the network
function addNewOrderer () {
  echo
  echo "###############################################################"
  echo "####### Generate and submit config tx to add Org3 #############"
  echo "###############################################################"
  docker exec -i cli  scripts/add_new_orderer_step.sh $CHANNEL_NAME  $ORDERER_ADDRESS $ORDERER_CA  $NEW_ORDERER_HOST $NEW_ORDERER_PORT
  if [ $? -ne 0 ]; then
    echo "ERROR !!!! Unable to create config tx"
    exit 1
  fi
}


CHANNEL_NAME=ebidsun-alpha
#ORDERER_ADDRESS=orderer3.bidsun.com:9050
ORDERER_ADDRESS=orderer.bidsun.com:7050
ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem
NEW_ORDERER_HOST=$1
NEW_ORDERER_PORT=$2

printHelp() {
    echo "Usage: ./add_new_orderer.sh new_order_host new_orderer_port "
    echo "注意: 需要先拷贝对应orderer节点的tls证书至channel-artifacts目录下, 比如orderer2.bidsun.com则需要将其证书server.crt拷贝至channel-artifacts/orderer2.bidsun.com_server.crt"
    echo "具体操作: cp crypto-config/ordererOrganizations/bidsun.com/orderers/orderer2.bidsun.com/tls/server.crt channel-artifacts/orderer2.bidsun.com_server.crt"
    echo "Example: ./add_new_orderer.sh orderer2.bidsun.com 8050"
}

if [ -z $NEW_ORDERER_HOST ];then
    echo "排序节点域名为空"
    printHelp
    exit 0
fi
if [ -z $NEW_ORDERER_PORT ];then
   echo "排序节点端口号为空"
    printHelp
   exit 0
fi

echo "new orderer host: $NEW_ORDERER_HOST"
echo "new orderer port: $NEW_ORDERER_PORT"
addNewOrderer
