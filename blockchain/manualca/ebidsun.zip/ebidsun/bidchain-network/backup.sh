#!/bin/bash

baseDir=/home/services/bidsun/bidchain/bidchain_db/
orderer1Dir=$baseDir/orderer.bidsun.com
orderer2Dir=$baseDir/orderer2.bidsun.com
orderer3Dir=$baseDir/orderer3.bidsun.com
peer0BidsunDir=$baseDir/peer0.bidsun.com
peer0GuangzhouDir=$baseDir/peer0.guangzhou.com

function testInvoke() {
    #index=1
    index=1382
    keyPrefix=x
    valuePrefix=y

    while true; do
        ccInvoke ${keyPrefix}${index} ${valuePrefix}${index}
        index=$((index+1))
    done
}

trap 'kill $BGPID; exit' INT 
testInvoke &
BGPID=$!


#while true; do
#    echo "current time:" `date +"%Y/%m/%d %H:%M:%S"`
#    (cd $orderer1Dir &&  sudo git add . && sudo git commit -m "orderer `date +\"%Y/%m/%d %H:%M:%S\"`") &
#    pid1=$!
#    (cd $orderer2Dir && sudo git add . && sudo git commit -m "orderer2 `date +\"%Y/%m/%d %H:%M:%S\"`") &
#    pid2=$!
#    (cd $orderer3Dir && sudo git add . && sudo git commit -m "orderer3 `date +\"%Y/%m/%d %H:%M:%S\"`") &
#    pid3=$!
#    (cd $peer0BidsunDir && sudo git add . && sudo git commit -m "peer0.bidsun `date +\"%Y/%m/%d %H:%M:%S\"`") &
#    pid4=$!
#    (cd $peer0GuangzhouDir && sudo git add . && sudo git commit -m "peer0.guangzhou `date +\"%Y/%m/%d %H:%M:%S\"`") &
#    pid5=$!
#    wait $pid1 $pid2 $pid3 $pid4 $pid5
#    sleep 60
#done

index=0
ordererPid=0
while true; do
  if [[ $index -eq 0 ]]; then
    #(docker pause orderer.bidsun.com && cd $orderer1Dir &&  sudo git add . && sudo git commit -m "orderer `date +\"%Y/%m/%d %H:%M:%S\"`" && docker unpause orderer.bidsun.com) &
    #ordererPid=$!
    cn=orderer.bidsun.com
    ordererDir=$orderer1Dir 
  elif [[ $index -eq 1 ]]; then
    #( docker pause orderer2.bidsun.com && cd $orderer2Dir && sudo git add . && sudo git commit -m "orderer2 `date +\"%Y/%m/%d %H:%M:%S\"`" && docker unpause orderer2.bidsun.com ) &
    #ordererPid=$!
    cn=orderer2.bidsun.com
    ordererDir=$orderer2Dir 
    
  else
    #(docker pause orderer3.bidsun.com && cd $orderer3Dir && sudo git add . && sudo git commit -m "orderer3 `date +\"%Y/%m/%d %H:%M:%S\"`" && docker unpause orderer3.bidsun.com ) &
    #ordererPid=$!
    cn=orderer3.bidsun.com
    ordererDir=$orderer3Dir 
  fi
  echo $cn
  ordererStatus=$(docker inspect $cn | jq -r .[].State.Status) 
  if [[ $ordererStatus = "paused" ]]; then
    docker unpause $cn
    sleep 1
  fi
  #set -x && docker pause $cn && sleep 1  && cd $ordererDir && sudo git add . && sudo git commit -a -m "$cn `date +\"%Y/%m/%d %H:%M:%S\"`" && echo hello && docker unpause $cn && set +x
  #(set -x && docker pause $cn && sleep 1  && cd $ordererDir && sudo git add . && sudo git commit -a -m "$cn `date +\"%Y/%m/%d %H:%M:%S\"`" && docker unpause $cn && set +x) &
  { docker pause $cn ; sleep 1; cd $ordererDir ; sudo git add . ; sudo git commit -a -m "$cn `date +\"%Y/%m/%d %H:%M:%S\"`" ; docker unpause $cn ; } &
  ordererPid=$!
  (cd $peer0BidsunDir && sudo git add . && sudo git commit -a -m "peer0.bidsun `date +\"%Y/%m/%d %H:%M:%S\"`") &
  pid4=$!
  (cd $peer0GuangzhouDir && sudo git add . && sudo git commit -a -m "peer0.guangzhou `date +\"%Y/%m/%d %H:%M:%S\"`") &
  pid5=$!
  wait $ordererPid $pid4 $pid5
  sleep 60
  index=$((index+1))
  if [[ $index -eq 3 ]]; then
    index=0
  fi
done
