
declare -A chaincodeMap
for cp in `cat scripts/wantedChaincodes.txt | grep -v ^#`; do
    cc=$(basename $cp)
    chaincodeMap[$cc]=$cc
done
echo "chaincodeMap:" ${chaincodeMap[@]}

file="tt_wim_cc"
# 如果不是想要安装的，跳过
    if ! [[ ${chaincodeMap[$file]} ]]; then
        echo "不安装"
    fi


:<<!
configPath="$GOPATH/src/bidchain/chaincode/fabric_info_local.json"
mspList="BidsunMSP GuangzhouMSP"
for msp in $mspList; do
    echo "========================================msp": $msp "======================================"

    chaincodePaths=$(jq -r '.MSP | .["'$msp'"] | .chaincodes[] | .chaincodePath' $configPath | sort | uniq)
    echo "chaincodeList:" $chaincodePaths

    peerList=$(jq -r '.MSP | .["'$msp'"] | .peers[]' $configPath)
    echo "peerList:" $peerList
done
!
