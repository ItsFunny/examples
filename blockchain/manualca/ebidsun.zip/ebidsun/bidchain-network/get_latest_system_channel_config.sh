#!/bin/bash

CHANNEL_NAME="bidchain-sys-channel"

docker exec cli bash -c '
CORE_PEER_ADDRESS=orderer.bidsun.com:7050
CORE_PEER_LOCALMSPID=OrdererMSP
CORE_PEER_TLS_ENABLED=true
CORE_PEER_TLS_CERT_FILE=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/tls/server.crt
CORE_PEER_TLS_KEY_FILE=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/tls/server.crt 
CORE_PEER_TLS_ROOTCERT_FILE=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/tls/ca.crt
CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/ordererOrganizations/bidsun.com/users/Admin@bidsun.com/msp/
ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem


CHANNEL_NAME="bidchain-sys-channel"

echo "channel name: " $CHANNEL_NAME
peer channel fetch config config_block.pb -o orderer.bidsun.com:7050 -c $CHANNEL_NAME --tls --cafile $ORDERER_CA
configtxlator proto_decode --input config_block.pb --type common.Block | jq .data.data[0].payload.data.config > channel-artifacts/$CHANNEL_NAME"_latest_config.json"
' xxx $CHANNEL_NAME  # 这里,将xxx赋值给$0
mv ./channel-artifacts/$CHANNEL_NAME"_latest_config.json" .

