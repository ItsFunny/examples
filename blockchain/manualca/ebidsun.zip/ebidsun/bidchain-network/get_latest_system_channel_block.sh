#!/bin/bash

CHANNEL_NAME="bidchain-sys-channel"

docker exec cli bash -c '
CORE_PEER_ADDRESS=orderer.bidsun.com:7050
CORE_PEER_LOCALMSPID=OrdererMSP
CORE_PEER_TLS_ENABLED=true
CORE_PEER_TLS_CERT_FILE=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/tls/server.crt
CORE_PEER_TLS_KEY_FILE=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/tls/server.crt 
CORE_PEER_TLS_ROOTCERT_FILE=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/tls/ca.crt
CORE_PEER_MSPCONFIGPATH=/opt/workspace/crypto/ordererOrganizations/bidsun.com/users/Admin@bidsun.com/msp/
ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem


CHANNEL_NAME="bidchain-sys-channel"

echo "channel name: " $CHANNEL_NAME
peer channel fetch config config_block.pb -o orderer.bidsun.com:7050 -c $CHANNEL_NAME --tls --cafile $ORDERER_CA
mv config_block.pb ./channel-artifacts/system-channel.block 
' 

