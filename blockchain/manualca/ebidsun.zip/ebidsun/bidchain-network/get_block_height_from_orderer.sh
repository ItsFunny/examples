#!/bin/bash


ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem
channelName="ebidsun-alpha"
#ordererAddress="orderer.bidsun.com:7050"
for ordererAddress in "orderer.bidsun.com:7050" "orderer2.bidsun.com:8050" "orderer3.bidsun.com:9050"; do
    docker exec cli peer channel fetch newest tmp.block -c $channelName --orderer $ordererAddress --tls --cafile $ORDERER_CA  &> /dev/null
    blockIndex=$(docker exec cli configtxlator proto_decode --input tmp.block --type common.Block | grep number | awk '{print $NF}' | grep -oP '\d+')
    channelBlockHeight=$((blockIndex+1))
    #echo "orderer: $addr, channel: $channelName 's block height: $channelBlockHeight"
    printf "orderer=[%s],channel=[%s],block height=[%d]\n" $ordererAddress $channelName $channelBlockHeight
    docker exec cli rm tmp.block 
done
