#!/bin/bash

# "absolute_max_bytes": 103809024,
# "max_message_count": 1000,
# "preferred_max_bytes": 524288


