function askProceed() {
  read -p "Are you sure to clean the whole network? [Y/n] " ans 
  case "$ans" in
  y | Y | "") 
    echo "proceeding ..."
    ;;  
  n | N)
    echo "exiting..."
    exit 1
    ;;  
  *)  
    echo "invalid response"
    askProceed
    ;;  
  esac
}

askProceed
docker rm -f peer0.bidsun.com peer0.guangzhou.com orderer.bidsun.com cli
cids=`docker ps -a  | grep -E "dev|hyperledger/fabric"  | cut -d " "  -f1`
docker stop $cids
docker rm -f $cids
sudo rm -rf ~/bidsun/bidchain/bidchain_db/* workspace/*
#sudo rm -rf ~/bidsun/bidchain/bidchain_db/peer0.bidsun.com/* ~/bidsun/bidchain/bidchain_db/peer0.guangzhou.com/* workspace/*

docker rmi -f $(docker images | grep dev | awk '{print $3}')
docker network prune -f
docker volume prune -f

