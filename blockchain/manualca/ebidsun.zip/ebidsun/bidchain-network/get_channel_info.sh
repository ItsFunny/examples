#!/bin/bash

docker exec cli bash -c "echo \$CORE_PEER_LOCALMSPID > ./msp.txt"
msp=$(cat ./workspace/msp.txt)
echo "msp": $msp

channelNameList=$1
if [[ $channelNameList = "" ]]; then
  configFile=$GOPATH/src/bidchain/chaincode/fabric_info_local.json  
  #local configFile=$GOPATH/src/bidchain/chaincode/fabric_config_online.json  
  channelNameList=$(jq -r '.MSP | .["'$msp'"] | .channels[]' $configFile)
fi

echo "channelNameList:" $channelNameList
PEER_ADDRESS=$(docker exec cli bash -c 'echo $CORE_PEER_ADDRESS')
echo "============= peer address: $PEER_ADDRESS =======================" 
echo "================= installed chaincode =====================" 
docker exec cli peer chaincode list --installed
echo ""
echo ""
echo ""

echo "===========================================instantiated chaincodes======================================"
for channelName in $channelNameList; do 
    echo "================================================= [$channelName] ======================================================"
    docker exec cli peer channel getinfo -c $channelName
    echo ""
    echo "================================================= instantiated chaincodes ======================================================"
    docker exec cli peer chaincode list --instantiated -C $channelName
    echo ""
    echo "----------------------------------------------------------------------------------------------------------------------"
done

