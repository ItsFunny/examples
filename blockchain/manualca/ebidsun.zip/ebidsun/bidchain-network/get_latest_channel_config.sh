#!/bin/bash

CHANNEL_NAME=$1
: ${CHANNEL_NAME:=ebidsun-alpha}

docker exec cli bash -c '
ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem

CHANNEL_NAME=$1
: ${CHANNEL_NAME:=ebidsun-alpha}

echo "channel name: " $CHANNEL_NAME
set -x
peer channel fetch config config_block.pb -o orderer.bidsun.com:7050 -c $CHANNEL_NAME --tls --cafile $ORDERER_CA
set +x
configtxlator proto_decode --input config_block.pb --type common.Block | jq .data.data[0].payload.data.config > channel-artifacts/$CHANNEL_NAME"_latest_config.json"
' xxx $CHANNEL_NAME  # 这里,将xxx赋值给$0
mv ./channel-artifacts/$CHANNEL_NAME"_latest_config.json" .

