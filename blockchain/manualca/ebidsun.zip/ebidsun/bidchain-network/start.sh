
docker exec cli scripts/installChaincodes.sh
docker exec cli scripts/instantiateOrUpgradeChaincodes.sh
