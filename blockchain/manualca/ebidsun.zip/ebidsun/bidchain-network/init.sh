#!/bin/bash

echo "creating orderer genesis block"
configtxgen -profile SampleMultiNodeEtcdRaft -channelID bidchain-sys-channel -outputBlock ./channel-artifacts/genesis.block
#configtxgen -profile BidchainMultiNodeEtcdRaft -channelID bidchain-sys-channel -outputBlock ./channel-artifacts/genesis.block
#exit 0


#docker-compose -f docker-compose-cli.yaml -f docker-compose-etcdraft2.yaml up -d
docker-compose -f docker-compose-cli.yaml  up -d
if [[ $? -ne 0 ]]; then
    exit 0
fi

echo "sleep 15s for network to startup"
sleep 5



./create_channel.sh

