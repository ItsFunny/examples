#!/bin/bash

dataDir=$(docker info | grep -P "Docker Root Dir:" | awk -F ":" '{print $2}' | tr  -d ' ')
for containerName in "orderer.bidsun.com" "orderer2.bidsun.com" "orderer3.bidsun.com" "peer0.bidsun.com" "peer0.guangzhou.com"; do
        echo "containerName: $containerName"
        cid=$(docker ps -aqf "name=^${containerName}$")
        fullCid=$(sudo ls $dataDir/containers | grep $cid | head -1)
        logPath=$dataDir/containers/${fullCid}/${fullCid}-json.log
        echo "container logPath:" $logPath
        sudo bash -c "> $logPath"
done
