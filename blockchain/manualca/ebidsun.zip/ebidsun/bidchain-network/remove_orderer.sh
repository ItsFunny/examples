
# Use the CLI container to create the configuration transaction needed to add
# to the network
function removeOrderer () {
  echo
  echo "###############################################################"
  echo "####### Generate and submit config tx to add Org3 #############"
  echo "###############################################################"
  docker exec cli scripts/remove_orderer_step.sh $CHANNEL_NAME  $ORDERER_ADDRESS $ORDERER_CA  $NEW_ORDERER_HOST $NEW_ORDERER_PORT 
  if [ $? -ne 0 ]; then
    echo "ERROR !!!! Unable to create config tx"
    exit 1
  fi
}


CHANNEL_NAME=ebidsun-alpha
ORDERER_ADDRESS=orderer.bidsun.com:7050
ORDERER_CA=/opt/workspace/crypto/ordererOrganizations/bidsun.com/orderers/orderer.bidsun.com/msp/tlscacerts/tlsca.bidsun.com-cert.pem
NEW_ORDERER_HOST=$1
NEW_ORDERER_PORT=$2
NEW_ORDERER_TLS_CERT_FILE=$3

printHelp() {
    echo "Usage: ./remove__orderer.sh new_order_host new_orderer_port 
    echo "Example: ./remove_orderer.sh orderer2.bidsun.com 8050 
}

if [ -z $NEW_ORDERER_HOST ];then
    echo "排序节点域名为空"
    printHelp
    exit 0
fi
if [ -z $NEW_ORDERER_PORT ];then
   echo "排序节点端口号为空"
    printHelp
   exit 0
fi
echo "orderer host: $NEW_ORDERER_HOST"
echo "orderer port: $NEW_ORDERER_PORT"
removeOrderer
